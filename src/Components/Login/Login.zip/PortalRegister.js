import React, { useState } from "react";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import logo from "../../assets/logo.png";
import { useNavigate } from "react-router-dom";
import { Button, Form, InputGroup } from "react-bootstrap";
import { Link } from "react-router-dom";
import { postApi } from "../../service/axiosInterceptors";
import { setUserDetails } from "../../redux/reducers/UserReducer";
import { useDispatch } from "react-redux";

const PortalRegisterEng = () => {
  const dispatch = useDispatch();
  var lowerCaseLetters = /[a-z]/g;
  // Validate capital letters
  var upperCaseLetters = /[A-Z]/g;
  const [passwordType, setPasswordType] = useState("password");
  const [passwordInput, setPasswordInput] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const navigate = useNavigate();
  const [errors, setErrors] = useState({});
  const togglePassword = () => {
    setPasswordType(passwordType === "password" ? "text" : "password");
  };
  const handlePasswordChange = (event) => {
    setPasswordInput(event.target.value);
  };
  const validateForm = () => {
    const newErrors = {};

    if (!email) {
      newErrors.email = "Email is mandatory";
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      newErrors.email = "Please enter valid email address";
    } else if (!password) {
      newErrors.password = "Password is mandatory";
    }
    // else if (password.length < 8 || password.length >16 ) {
    //   newErrors.password = "Password Must be eight or more character";
    // }
    // else if(!lowerCaseLetters.test(password)){
    //   newErrors.password = "Please Enter at least one Lowercase characte";
    // }
    // else if(!upperCaseLetters.test(password)){
    //   newErrors.password = "Please Enter at least one Uppercase characte";
    // }
    //  else {
    //   newErrors.password = "";
    // }

    setErrors(newErrors);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    validateForm(); // Validate the form before submitting
    if (Object.keys(errors).every((key) => errors[key] === "")) {
      // Perform form submission here
      const data = { email, password };
      const res = await postApi("user/loginEmail", data)
        .then((res) => res)
        .catch((err) => err.response);
      if (res.status >= 400) {
        console.log("error", res.data.message);
        res.data && setErrors((pre) => ({ ...pre, error: true }));
      } else {
        if (res.data.success && res.status === 200 && res.data.access_token) {
          setErrors((pre) => ({ ...pre, error: false }));
          localStorage.setItem("token", res.data.access_token);
          dispatch(
            setUserDetails({
              token: res.data.access_token,
            })
          );
          navigate("/");
        }
      }
    }
  };
  return (
    <div className="container-fluid loginboxpage">
      <img src={logo} alt="logo" className="loginbg" />
      <div className="container">
        <Row className="justify-content-center">
          <Col lg={6} md={6} sm={12} xs={12}>
            <div className="login-box">
              <h3 className="mb-4">
                साइन इन करण्यासाठी, कृपया
                <br />
                तुमचा इमेल पत्ता लिहा
              </h3>
              <InputGroup className="mb-4">
                <InputGroup.Text id="basic-addon1">
                  <i className="fa fa-envelope" aria-hidden="true"></i>
                </InputGroup.Text>
                <Form.Control
                  type="email"
                  placeholder="ई-मेल आयडी"
                  aria-label="ई-मेल आयडी"
                  aria-describedby="basic-addon1"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  onBlur={validateForm} // Validate on blur
                />
              </InputGroup>
              {errors.email && <p className="error">{errors.email}</p>}
              <InputGroup className="mb-4">
                <InputGroup.Text id="basic-addon1">
                  <i className="fa fa-lock" aria-hidden="true"></i>
                </InputGroup.Text>
                <Form.Control
                  type={passwordType === "password" ? "password" : "text"}
                  placeholder="पासवर्ड"
                  aria-label="पासवर्ड"
                  aria-describedby="basic-addon1"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  onBlur={validateForm} // Validate on blur
                />
                <div className="input-group-btn">
                  <span onClick={togglePassword}>
                    {passwordType === "password" ? (
                      <i className="fa fa-eye-slash"></i>
                    ) : (
                      <i className="fa fa-eye"></i>
                    )}
                  </span>
                </div>
              </InputGroup>
              {errors.password && <p className="error">{errors.password}</p>}
              {errors.error && (
                <p className="error">{"something went wromg"}</p>
              )}
              <div className="Forgot-Pass">पासवर्ड विसरलात?</div>
              <Button variant="primary" onClick={handleSubmit} className="mt-3">
                Sign In
              </Button>
              <div className="horizontal-lines mt-5 mb-3">
                <div className="horizontal-line"></div>
                <div className="text">किंवा</div>
                <div className="horizontal-line"></div>
              </div>
              <div className="text-center mt-5 mb-5">
                <Link to="/phone-login">
                  <button variant="primary" className="phone-login ">
                    <i class="fa-solid fa-phone-volume"></i>फोन नंबरसह साइन इन
                    करा
                  </button>
                </Link>
              </div>

              <a className="new_account">
                खाते नाही?{" "}
                <span>
                  <Link to="/SignupPortal">साइन अप करा</Link>
                </span>
              </a>
            </div>
          </Col>
        </Row>
      </div>
    </div>
  );
};

export default PortalRegisterEng;
