import React, { useState } from "react";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import logo from "../../assets/logo.png";
import { Button, Form, InputGroup } from "react-bootstrap";
import RegisterEng from "./RegisterEng";
import { useNavigate } from "react-router-dom";
import { postApi } from "../../service/axiosInterceptors";

const Verifyotp = () => {
  const navigate = useNavigate();
  const [Error, setError] = useState(false);
  const [Message, setMessage] = useState("");
  const [OTPS, setOTPS] = useState({
    otp1: "",
    otp2: "",
    otp3: "",
    otp4: "",
  });
  const handleChange = (e) => {
    setOTPS((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (Object.keys(OTPS).every((key) => OTPS[key] !== "")) {
      let otpValue = Object.values(OTPS).toString();
      console.log(otpValue);
      const data = {
        email_otp: otpValue.replace(",", ""),
        email: localStorage.getItem("temp_email"),
      };
      const res = await postApi("user/verifyEmail", data)
        .then((res) => res)
        .catch((err) => err.response);
      if (res.status >= 400) {
        setError(true);
        let msg = res.data.message && res.data.message.replace("Error:", "");
        setMessage(msg);
        console.log("error", res);
      } else {
        setError(false);
        console.log("response ", res);
        localStorage.setItem("token", res);
        navigate("/PortalRegister");
      }
    } else {
      setError(true);
      setMessage("Please Enter Valid Otp");
    }
  };

  return (
    <div className="container-fluid loginboxpage">
      <img src={logo} alt="logo" className="loginbg" />
      <div className="container">
        <Row className="justify-content-center">
          <Col lg={6} md={6} sm={12} xs={12}>
            <div className="login-box">
              <h3 className="mb-3">
                साइन इन करण्यासाठी, कृपया
                <br />
                तुमचा इमेल पत्ता लिहा
              </h3>
              <h6 className="mb-4">कृपया आम्ही पाठवलेला कोड टाइप करा</h6>

              <div className="otp-box ">
                <input
                  type="text"
                  class="otp-input"
                  maxlength="1"
                  //   oninput={moveToNext(this, 2)}
                />
                <input
                  type="text"
                  class="otp-input"
                  maxlength="1"
                  //   oninput={moveToNext(this, 2)}
                />
                <input
                  type="text"
                  class="otp-input"
                  maxlength="1"
                  //   oninput={moveToNext(this, 2)}
                />
                <input type="text" class="otp-input" maxlength="1" />
              </div>

              <div className="code-text mt-4">
                <h6>
                  <div className="code-again">कोड पुन्हा पाठवा (" ")</div>
                  <br />
                  <a
                    href="#"
                    className="code-link"
                    style={{ marginTop: "-5px" }}
                  >
                    लिंक पुन्हा पाठवा
                  </a>
                </h6>
              </div>

              <Button variant="primary" onClick={handleSubmit} className="mt-4">
                सुरू
              </Button>
              <a className="new_account">
                खाते नाही?{" "}
                <span>
                  <a href="#">साइन अप करा</a>
                </span>
              </a>
            </div>
          </Col>
        </Row>
      </div>
    </div>
  );
};

export default Verifyotp;
